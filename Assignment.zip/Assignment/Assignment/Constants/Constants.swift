//
//  Constants.swift
//  Assignment
//

import Foundation

struct Constants {
    static let weatherUrl = "http://api.openweathermap.org/data/2.5/weather?"
    static let apiKey = "fae7190d7e6433ec3a45285ffcf55c86"
    static let helpUrl = "https://openweathermap.org/api"
}


