//
//  LocationSingleton.swift
//  Assignment
//

import Foundation

struct LocationSingleton {
    static var locations = Array<Cordinates>()
}
